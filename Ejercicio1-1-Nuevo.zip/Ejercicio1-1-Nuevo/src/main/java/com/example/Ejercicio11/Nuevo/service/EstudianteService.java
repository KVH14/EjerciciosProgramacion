package com.example.Ejercicio11.Nuevo.service;

import com.example.Ejercicio11.Nuevo.entities.Estudiante;
import com.example.Ejercicio11.Nuevo.repository.EstudianteRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EstudianteService {
    private final EstudianteRepositorio estudianteRepositorio;

    public EstudianteService(EstudianteRepositorio estudianteRepositorio) {
        this.estudianteRepositorio = estudianteRepositorio;
    }

    public Estudiante crearEstudiante(Estudiante estudiante) {
        return estudianteRepositorio.guardar(estudiante);
    }

    public List<Estudiante> listarEstudiantes() {
        return estudianteRepositorio.listar();
    }

    public Estudiante obtenerEstudiantePorId(Long id) {
        return estudianteRepositorio.buscarPorId(id);
    }

    public boolean eliminarEstudiante(Long id) {
        return estudianteRepositorio.eliminar(id);
    }
}
