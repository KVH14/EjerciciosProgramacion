package com.example.Ejercicio11.Nuevo.repository;

import com.example.Ejercicio11.Nuevo.entities.Estudiante;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class EstudianteRepositorio {
    private final List<Estudiante> estudiantes = new ArrayList<>();

    public Estudiante guardar(Estudiante estudiante) {
        estudiantes.add(estudiante);
        return estudiante;
    }

    public List<Estudiante> listar() {
        return estudiantes;
    }

    public Estudiante buscarPorId(Long id) {
        return estudiantes.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst()
                .orElse(null);
    }

    public boolean eliminar(Long id) {
        return estudiantes.removeIf(e -> e.getId().equals(id));
    }
}
