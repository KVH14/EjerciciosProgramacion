package com.example.Ejercicio11.Nuevo.entities;

public class Tarea {
    private Long id;
    private String descripcion;
    private boolean entregada;

    public Tarea() {}

    public Tarea(Long id, String descripcion, boolean entregada) {
        this.id = id;
        this.descripcion = descripcion;
        this.entregada = entregada;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) { this.descripcion = descripcion; }

    public boolean isEntregada() { return entregada; }
    public void setEntregada(boolean entregada) { this.entregada = entregada; }
}
