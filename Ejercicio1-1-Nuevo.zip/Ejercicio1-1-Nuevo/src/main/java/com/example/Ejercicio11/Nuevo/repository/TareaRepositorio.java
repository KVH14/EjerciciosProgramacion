package com.example.Ejercicio11.Nuevo.repository;

import com.example.Ejercicio11.Nuevo.entities.Tarea;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class TareaRepositorio {
    private final List<Tarea> tareas = new ArrayList<>();

    public Tarea guardar(Tarea tarea) {
        tareas.add(tarea);
        return tarea;
    }

    public List<Tarea> listar() {
        return tareas;
    }

    public Tarea buscarPorId(Long id) {
        return tareas.stream()
                .filter(t -> t.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
}
