package com.example.Ejercicio11.Nuevo.controller;

import com.example.Ejercicio11.Nuevo.entities.Tarea;
import com.example.Ejercicio11.Nuevo.service.TareaService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/tareas")
public class TareaController {
    private final TareaService tareaService;

    public TareaController(TareaService tareaService) {
        this.tareaService = tareaService;
    }

    @PostMapping
    public Tarea crearTarea(@RequestBody Tarea tarea) {
        return tareaService.crearTarea(tarea);
    }

    @GetMapping
    public List<Tarea> listarTareas() {
        return tareaService.listarTareas();
    }

    @GetMapping("/pendientes")
    public List<Tarea> listarPendientes() {
        return tareaService.listarPendientes();
    }
}
