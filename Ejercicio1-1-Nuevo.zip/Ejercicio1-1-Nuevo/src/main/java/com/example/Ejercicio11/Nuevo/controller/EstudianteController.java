package com.example.Ejercicio11.Nuevo.controller;

import com.example.Ejercicio11.Nuevo.entities.Estudiante;
import com.example.Ejercicio11.Nuevo.service.EstudianteService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {
    private final EstudianteService estudianteService;

    public EstudianteController(EstudianteService estudianteService) {
        this.estudianteService = estudianteService;
    }

    @PostMapping
    public Estudiante crearEstudiante(@RequestBody Estudiante estudiante) {
        return estudianteService.crearEstudiante(estudiante);
    }

    @GetMapping
    public List<Estudiante> listarEstudiantes() {
        return estudianteService.listarEstudiantes();
    }

    @GetMapping("/{id}")
    public Estudiante obtenerEstudiante(@PathVariable Long id) {
        return estudianteService.obtenerEstudiantePorId(id);
    }

    @DeleteMapping("/{id}")
    public boolean eliminarEstudiante(@PathVariable Long id) {
        return estudianteService.eliminarEstudiante(id);
    }
}
