package com.example.Ejercicio11.Nuevo.service;

import com.example.Ejercicio11.Nuevo.entities.Tarea;
import com.example.Ejercicio11.Nuevo.repository.TareaRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TareaService {
    private final TareaRepositorio tareaRepositorio;

    public TareaService(TareaRepositorio tareaRepositorio) {
        this.tareaRepositorio = tareaRepositorio;
    }

    public Tarea crearTarea(Tarea tarea) {
        return tareaRepositorio.guardar(tarea);
    }

    public List<Tarea> listarTareas() {
        return tareaRepositorio.listar();
    }

    public List<Tarea> listarPendientes() {
        return tareaRepositorio.listar().stream()
                .filter(t -> !t.isEntregada())
                .toList();
    }
}
