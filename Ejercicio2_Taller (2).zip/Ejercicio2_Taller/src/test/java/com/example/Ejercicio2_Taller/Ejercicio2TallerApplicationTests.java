package com.example.Ejercicio2_Taller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ejercicio2TallerApplicationTests {

	@Test
	void contextLoads() {
	}

}
