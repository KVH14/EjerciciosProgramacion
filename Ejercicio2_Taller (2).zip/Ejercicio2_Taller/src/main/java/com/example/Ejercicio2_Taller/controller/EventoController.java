package com.example.Ejercicio2_Taller.controller;

import com.example.Ejercicio2_Taller.entities.Evento;
import com.example.Ejercicio2_Taller.service.EventoServicio;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/eventos")
public class EventoController {
    private final EventoServicio eventoServicio;

    public EventoController(EventoServicio eventoServicio) {
        this.eventoServicio = eventoServicio;
    }

    @PostMapping
    public Evento crearEvento(@RequestBody Evento evento) {
        return eventoServicio.crearEvento(evento);
    }

    @GetMapping
    public List<Evento> listarEventos() {
        return eventoServicio.listarEventos();
    }
}
