package com.example.Ejercicio2_Taller.controller;

import com.example.Ejercicio2_Taller.entities.Estudiante;
import com.example.Ejercicio2_Taller.service.EstudianteServicio;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/estudiantes")
public class EstudianteController {
    private final EstudianteServicio estudianteServicio;

    public EstudianteController(EstudianteServicio estudianteServicio) {
        this.estudianteServicio = estudianteServicio;
    }

    @PostMapping
    public Estudiante crearEstudiante(@RequestBody Estudiante estudiante) {
        return estudianteServicio.crearEstudiante(estudiante);
    }

    @GetMapping
    public List<Estudiante> listarEstudiantes() {
        return estudianteServicio.listarEstudiantes();
    }

    @GetMapping("/{id}/eventos")
    public List<?> listarEventosDeEstudiante(@PathVariable Long id) {
        Estudiante estudiante = estudianteServicio.obtenerEstudiantePorId(id);
        return estudiante != null ? estudiante.getEventosInscritos() : List.of();
    }

    @PostMapping("/inscribir")
    public String inscribirEstudiante(@RequestParam Long estudianteId, @RequestParam Long eventoId) {
        estudianteServicio.inscribirEstudiante(estudianteId, eventoId);
        return "Estudiante inscrito correctamente";
    }
}
