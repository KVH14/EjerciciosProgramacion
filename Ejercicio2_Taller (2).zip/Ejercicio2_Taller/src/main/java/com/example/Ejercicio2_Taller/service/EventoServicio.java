package com.example.Ejercicio2_Taller.service;

import com.example.Ejercicio2_Taller.entities.Evento;
import com.example.Ejercicio2_Taller.repository.EventoRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EventoServicio {
    private final EventoRepositorio eventoRepositorio;

    public EventoServicio(EventoRepositorio eventoRepositorio) {
        this.eventoRepositorio = eventoRepositorio;
    }

    public Evento crearEvento(Evento evento) {
        return eventoRepositorio.guardar(evento);
    }

    public List<Evento> listarEventos() {
        return eventoRepositorio.listar();
    }

    public Evento obtenerEventoPorId(Long id) {
        return eventoRepositorio.buscarPorId(id);
    }
}
