package com.example.Ejercicio2_Taller.service;

import com.example.Ejercicio2_Taller.entities.Evento;
import com.example.Ejercicio2_Taller.entities.Estudiante;
import com.example.Ejercicio2_Taller.repository.EstudianteRepositorio;
import com.example.Ejercicio2_Taller.repository.EventoRepositorio;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class EstudianteServicio {
    private final EstudianteRepositorio estudianteRepositorio;
    private final EventoRepositorio eventoRepositorio;

    public EstudianteServicio(EstudianteRepositorio estudianteRepositorio, EventoRepositorio eventoRepositorio) {
        this.estudianteRepositorio = estudianteRepositorio;
        this.eventoRepositorio = eventoRepositorio;
    }

    public Estudiante crearEstudiante(Estudiante estudiante) {
        return estudianteRepositorio.guardar(estudiante);
    }

    public List<Estudiante> listarEstudiantes() {
        return estudianteRepositorio.listar();
    }

    public Estudiante obtenerEstudiantePorId(Long id) {
        return estudianteRepositorio.buscarPorId(id);
    }

    public void inscribirEstudiante(Long estudianteId, Long eventoId) {
        Estudiante estudiante = estudianteRepositorio.buscarPorId(estudianteId);
        Evento evento = eventoRepositorio.buscarPorId(eventoId);
        if (estudiante != null && evento != null) {
            estudiante.inscribirEvento(evento);
        }
    }
}
