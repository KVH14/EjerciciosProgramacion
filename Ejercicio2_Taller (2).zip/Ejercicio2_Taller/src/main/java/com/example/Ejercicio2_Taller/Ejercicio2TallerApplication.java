package com.example.Ejercicio2_Taller;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ejercicio2TallerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ejercicio2TallerApplication.class, args);
	}

}
