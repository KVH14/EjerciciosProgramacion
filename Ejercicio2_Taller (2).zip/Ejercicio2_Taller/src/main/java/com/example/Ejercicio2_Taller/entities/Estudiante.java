package com.example.Ejercicio2_Taller.entities;

import java.util.ArrayList;
import java.util.List;

public class Estudiante {
    private Long id;
    private String nombre;
    private String correo;
    private List<Evento> eventosInscritos = new ArrayList<>();

    public Estudiante() {}

    public Estudiante(Long id, String nombre, String correo) {
        this.id = id;
        this.nombre = nombre;
        this.correo = correo;
    }

    // Getters y Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public List<Evento> getEventosInscritos() { return eventosInscritos; }

    public void inscribirEvento(Evento evento) {
        this.eventosInscritos.add(evento);
    }
}
