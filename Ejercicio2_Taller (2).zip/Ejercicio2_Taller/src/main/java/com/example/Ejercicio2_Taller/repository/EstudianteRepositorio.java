package com.example.Ejercicio2_Taller.repository;

import com.example.Ejercicio2_Taller.entities.Estudiante;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class EstudianteRepositorio {
    private final List<Estudiante> estudiantes = new ArrayList<>();

    public Estudiante guardar(Estudiante estudiante) {
        estudiantes.add(estudiante);
        return estudiante;
    }

    public List<Estudiante> listar() {
        return estudiantes;
    }

    public Estudiante buscarPorId(Long id) {
        return estudiantes.stream()
                .filter(s -> s.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
}
