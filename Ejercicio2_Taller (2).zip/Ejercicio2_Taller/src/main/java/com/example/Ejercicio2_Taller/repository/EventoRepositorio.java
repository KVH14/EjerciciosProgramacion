package com.example.Ejercicio2_Taller.repository;

import com.example.Ejercicio2_Taller.entities.Evento;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class EventoRepositorio {
    private final List<Evento> eventos = new ArrayList<>();

    public Evento guardar(Evento evento) {
        eventos.add(evento);
        return evento;
    }

    public List<Evento> listar() {
        return eventos;
    }

    public Evento buscarPorId(Long id) {
        return eventos.stream()
                .filter(e -> e.getId().equals(id))
                .findFirst()
                .orElse(null);
    }
}
